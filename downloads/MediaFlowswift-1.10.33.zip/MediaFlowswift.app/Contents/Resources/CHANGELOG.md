# What's New in MediaFlow

MediaFlow takes your footage from the card to the finished upload, and keeps every clip safe along the way. Here is what each new version brings.

*Every finished piece of work adds its line under "Coming next" before it is closed. When a version ships, that section takes the version's name.*

## Coming next

Nothing waiting. Everything finished so far is in 1.10.33.

## 1.10.33 · September 29, 2026

**Final Cut Pro libraries move with their media, every Mac knows where a shared project organizes, and a crash can’t lose an archive.**

- **Final Cut Pro libraries move with their shortcuts, and find their media wherever the project goes.** Every Final Cut Pro library keeps shortcuts inside it, to its cache and to its media, and some network storage lists them as ordinary files. Move to Editing Drive could then stop after an hour on a cache drive that wasn’t even connected, or copy your media twice over. Now every shortcut arrives as a shortcut, and the ones that point into your project follow it: on the editing drive, back in your library, on your archive drives and after a restore, even of an archive made with an earlier version, Final Cut finds its media in the project where it now is, not in the old place, even once you delete the original. Shortcuts take no room in the sizes shown or in an archive’s plan for its drives. And when a copy can’t finish, the window says so plainly: Didn’t Finish, with your original unchanged and the part-made copy removed, and “1 item failed” instead of “1 item(s)”.
- **Cancelling a subclip leaves nothing behind.** If you pressed Cancel at just the wrong moment while Create Subclip was working, a hidden, unfinished file could stay in the folder and later stop MediaFlowSwift from removing that folder when you moved, archived or tidied a project. Now a subclip export cleans up after itself, and anything it couldn’t remove at the time is cleared the next time you save a subclip under that name.
- **A fresh icon.** MediaFlowSwift’s icon now matches the one on mediaflowswift.com: a film frame with a play button, in the same teal, so the app in your Dock and the website look like one family.
- **After a crash, your Mac sends back only what you changed.** When your Mac stopped before sending its last changes to a shared database file and another Mac took the file over, MediaFlow already kept your Mac’s copy and sent your unsent work again. Now it sends exactly the clips, removals and project names you changed, and nothing else, so a note or rating someone added on another Mac to a clip you never touched stays theirs. A clip you added back to a project is added back there too. And MediaFlow now knows your Mac by its hardware, not its network name, so two Macs that happen to share a name never pass off each other’s work as their own, and a Mac you renamed still finds its own.
- **Details your Mac filled in come back after a crash, and a wrong clock can’t get in the way.** When your Mac stopped before sending its last changes and another Mac took over the shared database file, MediaFlow now also sends the details it filled in by itself, like a clip’s length and format, without touching anyone’s notes or ratings. And it works out which of your changes still need sending by counting how often your Mac’s copy was sent or refreshed, not by the clock, so a clock that was wrong, or was changed, never hides your work or sends an older change over someone else’s newer one.
- **Archives and restores survive a crash too.** If your Mac stopped right after you archived a project to your drives, or restored one, and another Mac then took over the shared database file, the database never heard about it. Now it is recorded again the next time you connect, with the same drives and date, and a restore with where its clips are now, unless another Mac has (or may have) changed that project since, in which case theirs stays. Where a clip’s file was found comes back the same careful way.
- **Every message can be read to the last word.** A long message in the corner of the window used to stop mid-sentence, just before the part that told you what to do. Now it shows its first lines with Show More, which opens the rest right there, and Show Less folds it again. Open as many as you like: the corner never grows past the window and scrolls instead, so every × and button such as Save As… stays in reach. Hovering shows the whole message, and VoiceOver reads every word. A message that clears itself now gives you more time the longer it is, and waits for as long as your pointer rests on it. Smart notifications and the messages in Prepare for YouTube open the same way. And when a project’s file is on another Mac or a drive that isn’t connected, the message now says first what happened, what happens to your changes and what to do, with the folder at the end.
- **Two Macs, one project, and always a clear answer about where it organizes.** The Mac that starts a project owns where its organized media goes, and every Mac sharing the project now finds that folder, even when a network share is connected under a slightly different name on each Mac. If your Mac can’t reach it, because it’s on the other Mac’s own drive or on a share that isn’t connected, Organize Media tells you whose folder it is and where, then offers to connect the share or to change the project’s destination to a folder every Mac reaches, with clips already organized following along once each is checked. It never quietly copies somewhere else instead. And New Project warns you, as you create the project, when the folder you picked is one the other Macs sharing your projects won’t be able to reach. A share whose name ends in a year, like “Studio-2024”, is no longer mistaken for one called “Studio”.
- **A new version asks, so you never miss one.** When a new version of MediaFlow is out, a window now shows what’s new and asks: Install Now, Later or Skip This Version. It waits until you’re not in the middle of something, never interrupts an import, a copy, an upload, your typing or another dialog, never grabs the screen from another app, and a key you meant for something else can’t answer it. Later asks again the next time you open MediaFlow, or in about a day. Skipped a version and changed your mind? Check for Updates… always offers the newest version, and Settings › General lets you take the skip back.

## 1.10.32 · September 27, 2026

**Subclips in your project, search across every project, and Macs that share a project stop undoing each other’s work.**

- **Cut your best moments into clips of their own.** Mark the part of a clip you want and choose Create Subclip, in the Workflow Tools tab or from the Workflow menu (Cmd+U). Add to This Project puts it straight into your project, listed under the clip it came from, with the same category, camera, scene, tags and notes, ready to rate and organize. Save to a Folder… still saves a file wherever you like, and now opens in the folder you used last and can replace a file. Either way the part keeps the clip’s own format and, whenever the clip allows, is copied as it is with no loss of quality; a progress bar shows how far it has got, and Cancel stops it cleanly.
- **Find any clip in any project, right from the search field.** Under the search field you now choose This Project, which narrows your clip list as before, or All Projects, which searches every project in your shared database as you type: any part of a file name, the notes, category, camera, scene or tags, or the project’s name. Edit → Search All Projects… takes you straight there. Found the shot you need in last year’s trip? Add to This Project copies it into the project you have open, checks every copy against the file it came from, and brings its category, tags, notes and rating along. The copy is this project’s own, so the other project stays exactly as it was, and tidying up this one never touches it. With no project open, search from the project browser, then open a clip’s project or start a new project with the clips you picked. It takes the place of the old Global Search window. All Projects searches your shared database, a database file on any plan or a database server with Studio Pro. Haven’t set one up yet, or is it turned off or out of reach? All Projects tells you exactly what it needs, in plain words, and one click takes you to the next step.
- **Start a shared database in one click.** In Settings › Storage and in the first-run setup, New Database File… asks only where your database should live, on this Mac or a network share, then makes it and connects. Use an Existing Database File… picks the one another Mac already made. Your database is never replaced: if a file is already there, you decide whether to use it, and a file that isn’t a MediaFlow database is turned away untouched. However you change the database file, even by typing its path, this Mac keeps its working copy of the old one to one side, so the file you chose is never written over with another database, and changes still waiting to be sent wait for the database they were made for.
- **Changes waiting for a database go only where you say.** Worked while your shared database was out of reach, then connected to a different one, or to a copy of the one your changes were meant for? MediaFlow now asks before sending them, and names both places: Send Them Here, Keep Waiting, or Don’t Send. Your project files keep every change whatever you choose, and nothing goes to a database you didn’t pick. Settings › Storage lists any changes still waiting for another database, so you can let them go if that database is gone for good.
- **Work your Mac hadn’t sent yet survives another Mac taking over.** If your Mac stopped before sending its last changes to a shared database file, after a crash or a forced quit, and another Mac then took the file over, your Mac used to replace its copy with the newer file and those changes were gone. Now it keeps its copy to one side, tells you where, and sends the projects with work the file was missing again from your project files. A Mac with nothing unsent never sends its older projects back over another Mac’s newer work: a project another Mac deleted stays deleted, and a clip it added back stays. A copy is only ever removed after MediaFlow has checked, byte for byte, that the file already holds everything in it.
- **One Projects list, always in view.** Projects › Browse Projects… now shows your Projects list right in the main window, with a Back button that returns you to the project you had open, just as you left it. A word left in the search field no longer hides your projects: opening, switching or closing a project empties it, and while clips from every project are showing, a line says so, with Clear to bring the list back. The count at the top always matches the list you see.
- **Run Setup Again shows up right away.** Run Setup Again… and Choose a plan… in Settings now close Settings and bring the setup or the plans straight to the front, instead of waiting behind Settings until you closed it. And Settings… opens even when you have closed the main window.
- **Space plays and pauses, in Review and in Import.** Tap Space to start and stop the clip in front of you in Review or in the Import sheet’s preview, whatever you clicked last, from the moment it opens. While a clip is showing, it never ticks a checkbox or presses a button by mistake, and in a text field it still types a space. Esc now closes the Import sheet, too. Space now also pauses a clip that is still loading from a network share, plays a finished clip again from the start, and works in the main window’s preview once you click it.
- **Help explains sharing a project between Macs.** Help now says exactly what a save sends to the shared database (the clips you changed, each one whole, not every clip in the project) and that opening a project from its file never copies the database’s clips into it. It also says when a save sends more, such as the first time a Mac sends changes the database hasn’t had, and how two Macs can work on one project without undoing each other’s work.
- **A project archived to one drive after a split archive restores from that drive.** A project archived across several drives, then archived again to a single drive, was still treated as split, so Restore from Archive asked for the old drives. It now restores from the one drive.
- **Saves of a project land in the order they were made.** Two saves close together could finish out of order, and the older one then put back what the newer one had just written. It was seen with the archive details that Archive to USB writes into the project file. Each project file is now written one save at a time, in order, including the last save when you quit or close the window. The file also keeps the same archive date as the shared database, so opening an archived project no longer redraws it for nothing.
- **Plain words, whatever your setup.** MediaFlowSwift no longer talks as if you own one particular kind of storage, or know what runs its shared database. Settings, menus, messages, Help and the macOS permission prompt now speak of your network share, a database file and a database server, so every word makes sense whether your footage lives on a share, an external drive or this Mac.
- **Free up space shows what is really left.** After Free Up Space moved your working copies to Cleanup, the Free up space step on the pipeline strip kept showing the same size and never got its green check. It now counts only the copies still on your Mac: it drops once they are moved, stays at zero once you delete them, and counts a copy again when Restore from Cleanup puts it back.
- **Opening an older copy no longer undoes someone else's notes.** Right after a project opens, MediaFlowSwift fills in what it can read for itself: a video's length and format, where its working copy is, whether its file has reached the destination. On a Mac with an older copy of a shared project, saving those used to send that Mac's old notes, ratings and tags along with them, over newer ones made on another Mac. Now only what was filled in is sent.
- **Free Up Space never throws away a folder it cannot see into.** At the end of a pass, MediaFlowSwift tidies away the Cleanup folders it has emptied. If a folder could not be looked into, on a network share that had a moment’s trouble for example, it was taken for empty and removed with everything still in it. Now a folder is removed only when it is seen to be empty, and the Mac itself refuses to remove one that is not.
- **Deleting after an archive checks every file was archived.** Deleting the project folder from the Archive Complete screen used to delete whatever was in it, even a render or an edit saved after the archive was made, or a hidden file a split archive had left out. MediaFlowSwift now deletes the folder only if every file in it was copied to the archive and checked, and has not changed since. Otherwise it keeps the folder, names the file and offers to archive again. Split archives now include hidden files too, a drive that ends up missing a file that was copied to it fails the archive, and when an archive cannot finish, the window now says why in words.
- **Nothing is deleted that was never copied.** A file whose name began like one of MediaFlowSwift’s own unfinished copies (“.incoming-” or “.superseded-” and a code) could make moving, archiving or returning from the editing drive miss the whole of the next folder, and then delete it with the original. Every folder is now copied, and a file with such a name, which is never copied, keeps the original or the editing copy from being deleted, with its name shown so you can rename it.
- **Deleting the original checks what is in it now.** After Move Project, deleting the old folder used to check only that the copy had files of the same names. A file saved into the old folder after the copy, under the same name, went with it. MediaFlowSwift now notes each file’s size and date before copying and keeps the old folder if anything in it has changed or been added since, telling you which file.
- **Studio Pro has no monthly limits.** Having your title, description and tags written, uploading to YouTube and reading back how your videos are doing no longer count against a monthly allowance, so nothing pauses in a busy month. Writing runs on your own provider account or a model on your Mac, and publishing on your own Google project, so your plan never meters them. Settings › Plan no longer has a This month section.
- **Change your plan without paying twice.** Moving up to Studio Pro, back to Studio, or between monthly and yearly now keeps the subscription and the key you already have. When a feature needs Studio Pro and you already subscribe, the Plans window no longer sends you to buy again, which would have started a second subscription: an Email Support… button opens a message to us in your mail app, and we move your plan for you.
- **Know what you are running, and who stands behind it.** MediaFlowSwift → About MediaFlowSwift now shows the version, who makes the app, what your Mac needs to run it (Apple silicon and macOS 14 Sonoma or later), and one-click links to the website, the support page, the terms of use and the privacy page. Settings › General shows the same. Acknowledgements… there credits the open-source software MediaFlowSwift is built with, each licence in full.
- **Support is one click away.** Help → Contact Support… opens a message to our support team in your own mail app, with your version of MediaFlowSwift, your macOS version and your Mac’s chip already filled in, so you only write the question. Help → Support Website takes you to answers to common questions. And when something goes wrong, Email Report… in Report a Problem hands the report, with your personal details already taken out, to your mail app addressed to us. Nothing goes until you press Send in your own email.
- **Just you and your Mac? Setup takes two questions.** The first-run setup now starts by asking where your footage goes — this Mac, an external drive, or a network share — and asks about a share and a shared database only if you have one. And a new project kept on your Mac’s own drive is no longer greeted with an orange warning, as if you had done something wrong: you see a plain note instead, and a warning only when your setup points to a share or another drive that may not be connected.
- **Your database password stays put after an update.** When macOS had not yet let the new version read the password saved for your database server, opening the server settings, or the setup wizard, and leaving again could erase it, so the next connection failed and you had to find and type it again. Now the password you type is saved when you press Return, test the connection or close Settings, and only if you changed it, so a stray key cannot replace it. While macOS is holding it back, the field says so, and leaving it blank keeps the saved password; if macOS will not let the app save a new one, you are told. A new Remove Saved Password… button, which asks first, is the one way to take it off your Mac.
- **A project opened from its archive drive knows it is archived.** Once you have deleted the original after archiving to USB, the drive holds the only copy. Opening it from the drive without the shared database used to show the Archive step as Pending. It now reads Archived, with the drive's number and the date, and a restore still brings the project back as not archived.
- **Your share reconnects without the app quitting.** When macOS dropped the share you chose in Settings › Network while MediaFlowSwift was open, the app could quit the moment it tried to connect it again, often overnight with nobody at the Mac. It now waits and reconnects the way it promised.
- **Only MediaFlowSwift’s own crashes are counted.** A crash report macOS wrote about another program that happened to share MediaFlowSwift’s name, such as a leftover from testing, no longer appears in your problem report, and no longer sets off the “macOS stopped MediaFlowSwift” notice when the app starts.
- **Copies proved against the drive, not memory.** Before MediaFlowSwift lets you remove anything, it reads its copy back and compares it with the original. Much of that reading used to come straight from your Mac’s memory, where the copy had just been written, so a failing drive or a loose cable could slip past it. Copies are now written and checked around that memory: on a drive connected to your Mac, the check reads what actually landed on the drive. Organize, Move Project, Move to Editing Drive, Return to Library, Archive, Restore, Duplicate Project and Free Up Space all check this way.
- **A copy kept from before a restore no longer says archived.** After a project was restored from its archive drive, the original you kept, or another earlier copy, still opened as archived to a drive it was no longer on. With the shared database connected, and the restored copy within reach of that Mac, it now opens as not archived, because the database records the restored copy as the project. The copy the database records keeps its archive details as before.
- **An archived project stays archived.** A project archived to USB and then opened again used to come back as if it had never been archived: the Archive step on the pipeline strip read Pending again. The project file now keeps which drive the project went to, where on it, and when. A project whose file lost that, opened while the shared database is connected, takes it from the database.
- **Loud audio no longer stops an import.** When MediaFlowSwift measured a clip’s sound levels after an import, audio that touched the very loudest level could make the app quit. It is now measured as full volume, as it should be. The same measurement behind Smart Selects and Workflow → Analyze… → Audio is fixed with it.
- **Two saves at once both land.** When two saves reached the shared database at the same moment (an import finishing while a rating was being saved, say), one of them could fail and have to wait for later. They now take turns.
- **Your edits kept while files move.** Rating, noting or tagging a clip while Move Project is running, or while a relinked clip’s new file is being checked, no longer gets undone when it finishes: those now change only where the file is and what is known about it.
- **Progress you can watch, even on huge clips.** Moving a project, sending it to the editing drive, archiving and restoring now keep the bar and the time left moving inside every file, and while each file is read back to check it, a step now shown as Checking. A multi-gigabyte clip no longer looks frozen, and Cancel stops at once, even in the middle of a check, without leaving a half-checked copy behind. That includes restoring a project from several drives, which Cancel could not stop before.
- **Opening a project no longer undoes your work.** Just after a project opens, MediaFlowSwift reads the length, picture size, frame rate and format of any video it does not know them for yet. That reading used to work on a copy of the project and put the copy back when it finished: a rating, a note or an import made in the meantime was lost, and a project opened meanwhile could be replaced by the one before it. Each video’s details now go straight onto that video, and the reading stops if you open another project.
- **Re-checking files no longer undoes your work.** MediaFlowSwift re-checks where your clips are whenever files change in the project folder, as well as from Workflow → Repair → Re-check files and the workflow templates. That check used to put back its own copy of any clip whose place had changed, so a rating, a note or a video’s details set while it ran were lost, and a project opened meanwhile could have the old places written into it. Now only where each clip is gets written, onto the clip as it is now, and nothing at all if you have opened another project. Move to Cleanup, Free Up Space and Restore from Cleanup keep your edits the same way.
- **No false Missing while clips are filed.** When MediaFlowSwift re-checked where your clips are while a category change was still moving a clip into its new folder, that clip could read Missing, and be saved that way, until the move finished. The re-check now leaves a clip that is on the move to the move, and looks at it again once it has landed. The new category and the new place stand either way.
- **Organize, Relink and a category change no longer undo your work.** When you change a clip’s category, MediaFlowSwift moves its organized file into the matching folder in the background while you carry on. That move, Organize Media, Workflow → Repair → Relink Missing Media… and Re-file folders by category used to work on copies of the clips taken when they started, and put the copies back when they finished: a rating, a note, a video’s details or a second category change made meanwhile was lost, and a project opened in the meantime could have them written into it. Now only where each file went is written, onto the clip as it is now, and a file whose category changed meanwhile moves on to the newer category’s folder. If you have opened another project by then, nothing is written or saved, and the summary says so.
- **An older copy no longer undoes someone else’s work.** When two Macs share a project, a save now sends the database only the clips changed on that Mac. A Mac with an older copy of the project no longer writes its old ratings, notes and tags back over newer ones made on the other Mac, and a rating saved on one Mac no longer undoes a rename made on another.
- **Copies that finish sooner.** Organizing, moving a project, sending it to the editing drive and back, archiving and restoring now move your footage in bigger pieces, and read each copy back to check it the same way, so large clips spend less time on the progress bar. Each copy is still read back and checked exactly as before.
- **Less waiting before and after the copy.** Moving a project or sending it to the editing drive now looks through the project folder once instead of six times, and restoring from an archive looks through each archive drive once instead of up to three times. On a network share, where every look is a trip across the network, that time adds up. Moving, archiving and restoring also now get the priority your Mac gives to work you are waiting on.
- **Much faster with lots of small files.** Organizing, moving a project, sending it to the editing drive and back, archiving, restoring and duplicating used to ask the drive to empty its own write memory after every single file. They now do it once, when the last file is copied, and still before anything is removed or your clips are pointed at the copies. Clear Card asks once more for each clip, just before it erases it from the card. A project with thousands of stills, proxies or sidecar files finishes many times sooner, and every copy is still read back and checked.
- **Copying and checking at the same time.** Moving a project, sending it to the editing drive, archiving and restoring now copy the next file while the last one is being read back and checked, so neither drive sits waiting for the other: about half as fast again on a Mac’s own disk. A file still counts only once its own check has passed, and if anything fails, everything stops and nothing unchecked is left behind.
- **Review says what each key just did.** In Review, F, X and C now flash what happened to the clip on screen: “★ Favorite”, “✕ Rejected” or “◉ Circle Take” when the mark goes on, and “Unfavorited”, “Unrejected” or “Uncircled” when it comes off. Each used to say the opposite. With no clip on screen they now say so, instead of claiming a mark was set.
- **Clips stay put when two Macs share a project.** Saving on a Mac whose copy of the project doesn’t yet have the clips someone else just added no longer takes them out of the project, and a clip removed on one Mac no longer comes back when a Mac with an older copy saves. Removing clips is now recorded as a removal, with when and from which Mac.
- **Every Mac on the same version.** Older versions of MediaFlowSwift saved whole copies of a project and could undo another Mac’s work. Once an up-to-date Mac has connected to your shared database server, the server refuses saves from those older versions, with a message to update. Their changes wait in their project files until they are. Update every Mac that shares the database.
- **A re-check no longer lets other work run ahead.** MediaFlowSwift re-checks where your clips are whenever files change in the project folder. When that check ended while something else was running, such as an import, an analysis, a report or an archive, the app took the other work for finished too: a workflow template could start its next step before the last one was done, and a command such as Move Project or Archive to USB could start alongside it. The re-check now keeps track of itself, and other work counts as busy until it is really done.
- **Cancel stops what you’re watching.** When a category change was filing clips into their folders in the background while a progress window was open, that window’s Cancel button could stop the background filing instead of the copy on screen. It now stops the window’s own work, every time, and Cancel in the window that deletes a project folder, clicked before the deleting starts, now keeps the folder. And when two category changes move files at once, MediaFlowSwift waits for both before it checks where your clips are, so a clip caught between two folders is no longer marked Missing.
- **A report that could not be written stops the workflow.** When the report step of a workflow template, such as End of Day Wrap, failed to write its report, the template said “Report written” and carried on. It now stops there and says why, as it does for any other step that fails. The error is still shown to you as before.
- **Review moves on only when you mean it.** With Auto-Advance on, F now moves to the next clip when it makes a clip a favorite, as X, A, R and the ratings do. Taking a favorite or a Reject off stays on the clip, and the last rating or mark you give a clip decides: pressing X twice quickly no longer skips the next clip, Up or Down Arrow during the short pause goes only where you asked, and closing Review during it leaves the clip you were on selected.
- **Your licence check has a second way through.** MediaFlowSwift now knows two addresses for its licence service, and tries the second only when the first cannot be reached, so your plan keeps being confirmed if the service moves. Activating a key also no longer holds the app up while it reads this Mac’s name. Settings › Privacy lists both addresses.
- **Clips kept in another person’s home folder no longer read Missing.** When two Macs share a project, clips imported on one of them are usually kept in that person’s home folder, where the other Mac cannot see them. Those clips now read On another Mac, in grey, and the two Macs stop changing them back and forth. They are left out of the Missing group, the missing counts and Organize, and Relink… can still point one at a copy on your own Mac.
- **Two Macs, one project: clearer notices and a safer Save As.** A project whose file is in a folder on the other Mac now says so, instead of waiting for a drive to come back, and suggests putting the file on a share both Macs reach. Save As from a project that opened from the shared database warns first that transcripts, the shot list, the storyboard and other things only the project file keeps won’t be in the new file; saving onto a copy of the same project keeps them. After Save As, the new file is where the project lives, and opening the file you left says it is an old copy. When the drive with the project’s file comes back while the database’s copy is open, the first save keeps what only the file had. An old copy left in a project’s destination folder no longer holds back the copy the database names.
- **Your two Macs stop marking each other’s clips Missing.** Each Mac now remembers the clips it has had: the ones you imported, organized, relinked or moved there, and every file it has found. Once a Mac has checked a project with this version, it marks a clip Missing only if it has had that clip. A clip imported on your other Mac and kept in its Shared folder, on its own drive, or in a home folder with the same name as yours reads Not on this Mac, in grey, and your two Macs stop changing it back and forth. The first check of each project file after you update works as before, so a file that went missing earlier still reads Missing, and a clip from your other Mac may read Missing once until that Mac checks it again. Clips that read Not on this Mac are left out of the missing counts and Organize, and Relink… can still point one at a copy on this Mac. Restore from Cleanup now puts a file back only where this Mac has had it, so a working copy staged on your other Mac is no longer put in your home folder on this one.
- **Two Macs no longer erase each other’s work in a shared database file.** A database file on a network share can be used by one Mac at a time, and MediaFlow now makes sure of it. A second Mac that connects is told who has the file (“Sheri’s MacBook Pro (Sheri Williams) is using the shared database, since 10:42”) and can wait, connecting by itself as soon as the other Mac lets go, or work without the database, with its changes synced later. A Mac that crashed or lost its connection loses its turn after five minutes, and the Mac that takes over says whose turn it was.
- **Two Macs saving one project file both keep their work.** When two Macs have the same project file open on a share, a save now looks first at whether the other Mac saved the file since. If it did, the clips it added come in with their transcripts and other details, the clips it removed go, and a clip changed on both Macs keeps both changes: a rating made there and a note written here both stay. The project’s own settings merge the same way, its archive record included. When both changed the same thing differently, this Mac’s change is kept, the other Mac’s version is saved in a Copies Kept Aside folder beside the project file, and a notice says where. A file that holds another project, or can’t be read, is never saved over: a project opened from the shared database no longer writes over another project’s file where its own used to be.
- **See who else has a project open.** When you open a project that someone has open on another Mac, MediaFlowSwift tells you once: “Sheri Smith has this project open on Sheri’s MacBook Air.” While they are in, the window title says so too (“also open on Sheri’s MacBook Air”), and it clears when they close it. Until changes arrive by themselves, edits you both make to the same clip at the same time can overwrite each other. It needs your shared database server; Macs sharing a database file take turns, as before.
- **Analysis no longer undoes your work.** AI Scene Analysis, Transcription, GPS extraction and the weather lookup used to work on a copy of the project taken when they started, and put that copy back when they finished: a rating, a note or an import made in the meantime was lost, and opening another project meanwhile could have it overwritten. Each result now goes straight onto the clip it belongs to, a pass stops if you open another project, and the results of AI Scene Analysis, GPS, weather and sun position are now saved like every other change.
- **Three windows you can close.** Exposure Analysis, Continuity Checker and Storyboard now have a Done button, and Escape closes them.
- **Rejecting a clip in Review teaches the suggestions.** Pressing R on a clip in Review now counts as disagreeing with what was suggested for it, so later suggestions learn from what you turned down as well as from what you took.
- **The inspector’s Enhanced tab is gone.** It showed a few video details and “No EXIF data available” for everything else; Full Metadata shows all of it and more. Help now describes each of the inspector’s tabs as they are.
- **Remove from Project, only when you mean it.** Delete removes the selected clips while you are working in the clip list or grid, and never while you are typing in Notes or Tags. File › Close Project, Duplicate and Revert to Saved are greyed out when there is nothing for them to do.
- **One Import in the menus.** File › Import… opens the Import sheet, where you choose a card or drive, an iPhone or a folder. The copies of it in the Workflow menu and the File menu are gone.
- **The old Project Dashboard and Checklist are gone.** The pipeline strip across the top of the window has shown where a project stands since 1.6. Your project files keep their checklist, so an older copy of MediaFlow still reads them.
- **Less written behind your back.** MediaFlow no longer keeps a second copy of every project in its own support folder, and no longer writes clip details to the shared database that nothing read back. Your project file and the database’s clip records are unchanged.

## 1.10.31 · September 25, 2026

**Clearer progress, a Review count you can trust, and no clip wrongly marked missing.**

- **Three small things on screen, put right.** The organize progress window lights Verify while each file is read back, instead of jumping back to Prepare. The card that ends an import points to the pipeline strip’s Auto-suggest or Workflow → Analyze… → Categories, not to a Tags menu that no longer exists. And Review, opened on unrated clips, keeps them in its queue as you rate them: the bar counts “2 of 10”, “3 of 10” and the rated count climbs, where it used to sit at “1 of …” with nothing rated, and Up Arrow goes back to a clip you just rated.

- **A clip on its way to a new category folder is no longer marked missing.** When you change a clip's category, MediaFlowSwift moves it into the new folder quietly in the background; it now waits for that move to finish before it re-checks where your clips are, so a clip caught halfway no longer shows up as missing.

## 1.10.30 · September 24, 2026

**Back on your database after an update, by itself.**

- **Back on your database after an update, without flipping a switch.** When macOS keeps a freshly updated MediaFlowSwift off your local network, the app no longer gives up after ten minutes: it keeps checking, less often as time goes on, checks again the moment you come back to it, and connects as soon as macOS lets it through. Nothing connects before you agree to the terms, either.

## 1.10.29 · September 24, 2026

**Your shared drive reconnects by itself.**

- **Your share comes back by itself.** When the network blinks or the server stops answering and macOS drops the share you chose in Settings › Network, MediaFlowSwift now reconnects it for you: after a few seconds, then every few minutes until it is back, with a strip at the top of the window saying so. It never asks for a password on its own, leaves a share you eject in Finder alone, and waits while your Mac sleeps.

## 1.10.28 · September 24, 2026

**Ready for customers: terms of use, and every copy updated from the website.**

- **Clear Card counts one clip properly.** Its finish screen now says “1 clip that could not be verified was left on the card”, not “were”, and “1 file was refused”; when nothing was kept, it leaves the line out rather than counting zero clips. The confirmation before deleting leaves out its zero too.
- **Every copy updates from the website.** New versions now come from mediaflowswift.com for everyone, checked every few hours and every half hour while you are offline, so there is nothing to choose in Settings › General › Updates. The option to update from a copy of the app on a share of your own is gone.
- **Terms of use, agreed once.** The first time MediaFlowSwift opens, it shows the terms it is sold under, with the main points in four short paragraphs, and starts once you click Agree; until then it connects to nothing and opens nothing. It asks again only when the terms change, and says what changed. Help › Terms of Use shows them any time. Your agreement is kept on your Mac and nowhere else, and on a new copy the free trial's 14 days start when you agree.

## 1.10.27 · September 24, 2026

**Ready to sell: your licence key, and new versions from the website.**

- **Only a real plan counts.** A shortcut the maker uses while building MediaFlowSwift, which could grant a plan without one, now works only in development builds, never in the app you install.
- **Your licence key.** Plans are bought on mediaflowswift.com, and the key from the thank-you page goes into Settings › Plan. One key works on up to three Macs, which Settings lists by name and can release. The app checks the key once a day and keeps the last answer for two weeks, so a trip without a connection pauses nothing. Settings › Privacy says exactly what the check sends, and to whom.
- **New versions from the MediaFlow website.** MediaFlowSwift can now update itself from mediaflowswift.com, and a fresh install does so from the start: one small file names the newest version, the download is checked against what the site promised and for its maker’s signature, and then it installs as before. A folder or share of your own still works, and is what a Mac already set up that way keeps using until you choose the website in Settings › General › Updates.

## 1.10.26 · September 22, 2026

**Your local network, kept after an update.**

- **Your local network, kept after an update.** The copy of the last version that MediaFlowSwift keeps for Revert now lives in its own support folder instead of beside the app in Applications. With two copies there, macOS sometimes judged the wrong one when the app asked for your local network after an update, and the shared database stayed out of reach until you flipped the switch. A copy still beside the app is moved the first time this version opens.

## 1.10.25 · September 22, 2026

**Hangs noticed, shares connected the direct way.**

- **Hangs noticed too.** MediaFlowSwift now also hears from Apple’s own diagnostics service about crashes and, new, about times it stopped responding, and tells you at the next launch, with the details ready for a report. The same fault told two ways is counted once.
- **Connecting your share, the direct way.** MediaFlowSwift now asks macOS to connect your network share itself, in one step, instead of going through a script: quicker, and when a password is needed it is macOS’s own dialog that asks.

## 1.10.24 · September 22, 2026

**Nothing new inside; a first run for the new installer.**

- **The same app, installed the new way.** This version changes nothing you will see. It exists so that the installer introduced in 1.10.23, which tells macOS which copy is the app before reopening, gets its first real run. If your local network connects without a trip to System Settings afterwards, it worked.


## 1.10.23 · September 22, 2026

**An update that introduces itself.**

- **An update that introduces itself.** After installing a new version, MediaFlowSwift now tells macOS which copy is the app before it reopens, so the permission you gave it for your local network is meant to carry over instead of asking for the switch once more. Help says plainly what to do if macOS still asks.

## 1.10.22 · September 22, 2026

**Studio and Studio Pro, with a trial of everything.**

- **Two plans, and a trial of everything.** MediaFlowSwift now comes as Studio, all the file management, and Studio Pro, which adds the writing, publishing and the database server. Every copy starts with 14 days of Studio Pro, no card asked. When a plan ends nothing you made is taken away: every project still opens and every clip still shows where it is; only new imports, Organize, proxies, the editing drive, writing, publishing and the server wait. Settings › Plan shows where you stand. Prices come with the first public release.

## 1.10.21 · September 22, 2026

**See what is new before you install it.**

- **Know what you are installing.** The update window now lists what is new in the version it offers: the headline and the points of every version you have not seen, straight from these notes. The banner carries the headline too.

## 1.10.20 · September 22, 2026

**The import list, in your order.**

- **Sort the import list your way.** In the Import sheet, click Filename, Date, Type, Length or Size to sort the clips on a card, a drive or a folder, click again to reverse, and MediaFlowSwift remembers your choice for the next import.

## 1.10.19 · September 22, 2026

**Your footage, found where it is.**

- **Signed by Apple's Developer ID.** From this version MediaFlowSwift carries Apple-verified signing and notarization, so macOS opens it without a warning on any Mac, and future updates no longer need the Local Network switch flipped or a password re-entered. This first time, macOS asks once.
- **Your share, connected when you need it.** MediaFlowSwift now connects the network share you chose by itself: shortly after launch, after your Mac wakes, and before opening any project that lives on it. And a clip whose drive is simply not plugged in is no longer called missing: it reads Volume not connected until the drive is back, and nothing about it is changed meanwhile.
- **A moved project opens where it is.** Open a project from the projects list and MediaFlowSwift now finds it even when it has moved since the list last saw it, and quietly points the list and your shared database at the new place. If the drive it lives on is not connected, the project opens from your shared database and says so once, with a Save As button, instead of failing to save three times a minute.

## 1.10.18 · September 21, 2026

**Ready for what comes next.**

- **The last update that asks.** MediaFlowSwift is moving to a signature from Apple’s Developer ID. This version is the bridge: it knows the new signature and will accept it. From the version after this one, an update no longer needs the network switch flipped or a password re-entered.
- **Reports get a first look within the hour.** Every problem report that reaches us gets an automatic first assessment, matched against the code and against earlier reports, usually within the hour, so a real fault stands out the day it is sent.

## 1.10.17 · September 21, 2026

**When something goes wrong, we hear about it, and you stay in control.**

- **Tell us what went wrong, in one click.** Help → Report a Problem puts together everything that helps find a fault, takes out your name, your drives, your folders and file names, the projects it knows and your computers, and shows you every word before you copy, save or send it. Sending is off until you turn it on, and even then nothing goes anywhere until you click Send. And if MediaFlowSwift ever quits on you, it notices next time and has the details ready.
- **Plain answers for plain problems.** A full disk, a locked card, a drive that dropped off: when a copy, an import or a save fails for one of those reasons, MediaFlowSwift now says which, and what to do about it.

## 1.10.16 · September 21, 2026

**One project, one truth, on every Mac.**

- **Your shared database, truly shared.** On a database server, saved changes to a project were not reaching the database at all: it kept only what it started with. Saves now reach it, so your projects list, your search and your other Macs see today’s work, not last week’s. And an old copy of a project, opened by mistake, can no longer overwrite the real one’s record.
- **Pick a copy once.** When MediaFlowSwift finds two copies of a project, your answer now sticks: the copy you choose is the one that opens next time.
- **A log you can read.** When something goes wrong behind the scenes, Help → Show Log now tells you what, and why.

## 1.10.15 · September 21, 2026

**Looks right on every screen.**

- **A tidy grid at any size.** On a smaller window, Grid view let each thumbnail spill over the tile beside it. Every tile now keeps to its own space, however narrow the window.

## 1.10.14 · September 21, 2026

**The right copy, every time.**

- **No more working in the wrong copy.** After you move your library, the old project files are still sitting on the old drive, looking just like the real thing. Open one by mistake and MediaFlowSwift now tells you, and takes you to the current copy in one click. And clips that are safe on another drive no longer claim to be "Only on card": they say where they really are.

## 1.10.13 · September 21, 2026

**It knows where everything is, and tells you when something is in the way.**

- **Always know where a project is.** Projects out on your editing drive now wear a badge in the projects list, on every Mac that shares your database. Drive not plugged in? MediaFlowSwift offers the library copy to look at instead. And if you move your library while a project is out, it still finds its way home.

- **Back online in seconds after an update.** Sometimes macOS quietly keeps a freshly updated app off your network, and your shared database stops connecting for no visible reason. MediaFlowSwift now spots that in a few seconds, tells you exactly which switch to flip, takes you there with one click, and reconnects by itself the instant you do.

## 1.10.12 · September 21, 2026

**Cut fast. Keep safe.**

- **Edit on your fastest drive.** Tell MediaFlowSwift where your fast storage is, and Move to Editing Drive puts the project you are cutting right on it, every file checked. Your library copy stays exactly where it is, untouched, as your safety net. When the cut is done, Return to Library shows what you made, carries back what you tick, checks every file against the library, and only then clears the fast drive for the next project.

## 1.10.11 · September 20, 2026

**Press play. It just plays.**

- **Smooth playback from your NAS, in one click.** Big 4K clips on a network drive can stutter when the network hiccups. When MediaFlowSwift sees you playing one, it offers to make a small, fast copy for previewing, for that clip or for the whole project, and switches to it right where you were watching. Your originals are never touched.

## 1.10.10 · September 20, 2026

**Moving house, made easy.**

- **New drive? One command.** Copied your library to a new NAS or drive? Library Moved points every project at the new place in one go. Nothing is copied, and MediaFlowSwift only follows a clip it has checked is the same file.

## 1.10.9 · September 20, 2026

**It remembers, so you don’t have to.**

- **No more silent stalls after an update.** If macOS needs your okay before MediaFlow can read a saved password, MediaFlow now tells you, and tells you exactly what to click.
- **Sorted the way you left it.** Pick a column to sort your clips or your projects by, and MediaFlow keeps it that way, next project and next launch.
- **One recording, one row.** When your GoPro splits a long take into several files, MediaFlow now shows it as a single row with the number of chapters and the total length. Click the arrow to see each piece. However you sort the list, the take stays together.
- **A welcome that knows when to leave.** The welcome tour opens once, not every time. A checkbox on it, and in Settings, brings it back whenever you want it.
- **Opens ready to work.** The main window now opens at a comfortable size, and MediaFlowSwift remembers where you left it, along with the rest of your view choices.

## 1.10.8 · September 20, 2026

**Your workspace, the way you want it.**

- **Resize the preview your way.** Drag the divider between the preview and the panel beside it to make either as wide as you like. The panel’s tabs now slide sideways when space is tight, and MediaFlow remembers the tab you were on.
- **GoPro clips in the right order.** Sort by filename and the pieces of one long GoPro recording now stay side by side, in the order you shot them, instead of being scattered down the list.

## 1.10.7 · September 20, 2026

**One app, update after update.**

- **Permissions that stick.** macOS now recognises every MediaFlow update as the same trusted app, so what you have allowed it, like reaching your NAS, stays allowed from one version to the next. If you are on 1.10.6 or earlier, install this version by hand once.
- **Safer updates.** MediaFlow checks that each update is genuine and from the same maker before installing it, and keeps your previous version ready in case you want to go back.
- **A straight answer about the network.** If macOS is keeping MediaFlow off your local network, MediaFlow now says so, and tells you where to switch it on.

## 1.10.6 · September 20, 2026

**A steadier connection to your shared library.**

- **No more false alarms.** With your library on a database server, MediaFlow no longer tells you the NAS is offline when it is not. And when that banner does have something to say, it sits in its own strip at the top, clear of your project list.
- **Your server, found instantly.** Version 1.10.5 could lose track of a server named with ".local" a moment after finding it. It now finds it straight away, every time, and stays connected.

## 1.10.5 · September 20, 2026

**Connecting your shared library just got easier.**

- **Finds your server by name.** Type your NAS’s name the way you know it and MediaFlow finds it, even when the network wants ".local" on the end. If something is off, it tells you whether to look at the name or the port.
- **Changes take effect at once.** Point MediaFlow at a different database server and it connects there and then. No more quitting and reopening.

## 1.10.4 · September 20, 2026

**Share your library with every Mac in the studio.**

- **A shared library, easier to start.** Setting up a database server for several Macs is now one click away in Settings, whichever kind of library you use today. The guide tells you exactly what it will create, and what to do next.

## 1.10.3 · September 20, 2026

**Updates you can count on.**

- **Updates that install, first time.** Version 1.10.1 could find an update but not finish installing it: it safely put itself back and reopened instead. That is fixed. If you are on 1.10.1 or 1.10.2, install this version by hand once, and every update after it takes care of itself.
- **A tidy update banner.** The "update available" banner now has its own strip at the top of the window, so it never sits on top of your project list.

## 1.10.2 · September 20, 2026

**Open a project the way you expect to.**

- **Double-click to open.** In the projects list, double-click any project and you are in. Right-click anywhere on its row for more, and one clear Open Selected button stays at the top.

## 1.10.1 · September 19, 2026

**Updates that finish the job.**

- **Never miss a new version.** MediaFlow now tells you when an update is ready, with a quiet banner at the top of the window. It keeps looking until it can reach your update folder, so a drive that connects late no longer means a missed update.
- **Click Install, and carry on.** MediaFlow closes, updates itself and comes straight back, ready to work. No more hunting for the icon to open it again.
- **Safe if anything goes wrong.** If an update cannot be installed, MediaFlow puts back the version you had and reopens it.

*One note: this improvement arrives with 1.10.1 itself, so you will see it from the next update onward. Installing 1.10.1 from an older version may still need you to reopen MediaFlow by hand, one last time.*

## 1.10.0 · September 19, 2026

**From final cut to YouTube, without leaving MediaFlow.**

- **Prepare for YouTube.** Choose your finished video and MediaFlow listens to it, then writes a title, description, chapters and tags built to be found. It works only from what you actually said, and checks its own work against YouTube's rules before you see a word. Every line is yours to edit.
- **Thumbnails that stop the scroll.** Pick the perfect frame, or let MediaFlow suggest the sharpest ones. Add a bold headline that stays readable on any picture, and export at exactly the size YouTube asks for.
- **Upload from where you work.** Sign in with your own Google account, choose Private, Unlisted, Public or a scheduled time, and send. A dropped connection picks up where it left off, even if you quit and come back tomorrow.
- **See how your videos are doing.** The new Results tab keeps a record of everything you publish. Turn on statistics and watch views, likes, comments, watch time and new subscribers grow over days, weeks and months.
- **Your privacy, your call.** Uploading and statistics are both off until you switch them on. MediaFlow tells you exactly what is sent and to whom, and never sees your Google password.

## 1.9.0 · September 18, 2026

**Find it faster. Trust it completely.**

- **Your footage, proven safe.** Before MediaFlow ever offers to delete an original, it now proves the copy is identical, file by file. That goes for archiving to a drive, moving a project, restoring, clearing a card and freeing up space.
- **Search your clips.** A search field for the clip list finds what you need by name, notes, tags and more. Press Command-F and type.
- **Find clips by what was said.** A new transcript panel lets you read, search, correct and export the words in any clip.
- **Remember the weather.** See the conditions a clip was shot in, and find your footage by them.
- **Stars and selects, everywhere.** Rate and mark your best clips in the table, the grid and the inspector.
- **Smoother playback.** When a lighter preview copy of a clip exists, MediaFlow plays it, and switches to the original with one click.
- **Privacy you control.** A new Privacy page in Settings lists every outside service MediaFlow can use. Each one is off until you turn it on.
- **Help where you need it.** Small ⓘ buttons beside the trickier controls explain them on the spot, and the full user guide is built from the same Help.
- **Plus:** workflow templates that wait for each step to finish, Select All and Shift-click in the grid, renaming a project renames its file, and a Storage Dashboard that opens at once.

## 1.8.0 · September 18, 2026

**Room to grow.**

- **A shared library for a whole team.** MediaFlow can now keep its library on a database server as well as in a single file, so several Macs can work from the same library with confidence.
- **Move between them in a few clicks.** Copy your whole library from one to the other, in either direction. Nothing is left behind.
- **Guided setup.** The setup assistant offers both choices and walks you through creating the server, step by step.

## 1.7.0 · September 17, 2026

**Up and running in minutes.**

- **A friendly first-run setup.** Three simple questions and you are ready: where your footage lives, whether you want a shared library, and where organized media should go. Skip any of them and come back later.
- **Settings that stay put.** Your setup now survives updates and reinstalls, and can be carried to a second Mac.

## 1.6.0 · September 11, 2026

**Make it yours.**

- **Works with your storage.** Nothing about your network is assumed. Let MediaFlow find your network drive, pick it, and go. It also works beautifully with no network drive at all.
- **Tidier Settings.** Everything is grouped into clear tabs, so the option you want is where you expect it.
- **Retire a category without losing history.** Old categories step aside quietly, and the clips that used them keep their labels.
- **Choose where updates come from.** Point MediaFlow at any folder and it will look there for new versions.

## 1.5.1 · September 11, 2026

**Polish.** Steadier syncing of your library in the background, and a round of small fixes.

## 1.5.0 · September 10, 2026

**A smarter import.**

- **Let MediaFlow suggest the category.** Tick one box when you import and MediaFlow looks at each clip and proposes where it belongs. It learns from every correction you make, and nothing is applied until you say so.
